const CONFIG = {
    titleWeb: "Tiêu đề web",
    introTitle: 'Tên người yêu bạn',
    introDesc: `Trái đất vốn lạ thường
    Mà sao em cứ đi nhầm đường
    Lạc vào tim anh lẻ loi
    Đằng sau chữ yêu đây là thương`,
    btnIntro: '^^HiHi^^',
    title: 'Phải chăng em đã yêu ngay từ cái nhìn đầu tiên 🥰',
    desc: 'Phải chăng em đã say ngay từ lúc thấy nụ cười ấy ',
    btnYes: 'Thích lắm <33',
    btnNo: 'Không nha :3',
    question: 'Trên thế giới hơn 7 tỉ người mà sao bạn lại yêu mình <3',
    btnReply: 'Gửi cho bạn <3',
    reply: 'Yêu thì yêu mà không yêu thì yêu <33333333',
    mess: 'Mình biết mà 🥰. Yêu bạn nhiều nhiều 😘😘',
    messDesc: 'Tối nay 7h, mình qua đón đi chơi nha.',
    btnAccept: 'Okiiiii lun <3',
    messLink: 'https://github.com/zukahai/Confess-Crush' //link mess của các bạn. VD: https://m.me/nam.nodemy
}